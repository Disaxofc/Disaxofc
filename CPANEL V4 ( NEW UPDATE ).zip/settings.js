const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel AlwaysAnan
global.owner = ['6283844662334'] //ur owner number
global.ownernomer = "6283844662334" //ur owner number2
global.ownername = "AlwaysSpy" //ur owner name
global.ytname = "YT: AlwaysSpy" //ur yt chanel name
global.socialm = "IG: @ha.nz7762" //ur github or insta name
global.location = "Arab Saudi" //ur location
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = 'https://wahidoffcxshasyyy.pteropanelku.biz.id' // isi dengan domain panel lu
global.apikey = 'ptla_xTOBXcURQlXGJ4l1o8rZ4HevJxF2MnJLbWyb8iLRRdq' // Isi Apikey Plta Lu
global.capikey = 'ptlc_7f8Ev8yA50PjOVj4y0EeqOM2h0jTsoLw3rLjQd4E7tD' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//new
global.ownergc = "AlwaysSpy"
global.botname = "Bot Cpanel Spy"
global.ownerNumber = ["6283844662334@s.whatsapp.net"]
global.ownerweb = "https://youtube.com/@alwaysanan"
global.themeemoji = '🪀'
global.wm = "YT: AlwaysSpy"
global.packname = "YT: AlwaysSpy"
global.author = "AlwaysSpy\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://files.catbox.moe/p9591h.jpg' }//ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Spy',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
